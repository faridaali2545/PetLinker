# PetLinker
Software Engineering Project

Members:
Azza Monir (Divide Branches)
Farida Ali
Malak Khaled (Merge Branches)
Nada Waleed (Leader)

 -------------
| flask setup  |
 -------------
pip install flask   //flask installation 
python -m venv venv //virtual environment setup
venv\Scripts\activate  //activating the environment for Windows 
source venv/bin/activate //activating the environment for macOS 
pip install -r requirements.txt //install requirements
