﻿global using Microsoft.EntityFrameworkCore;
global using PetLinker.Data;
